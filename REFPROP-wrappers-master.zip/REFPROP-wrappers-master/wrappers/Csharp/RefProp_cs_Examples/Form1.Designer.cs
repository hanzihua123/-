﻿namespace RefProp_cs_Examples
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.DataGridView_1st = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TextBox_1stTab_DewPoint = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.TextBox_1stTab_BubblePoint = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.TextBox_1stTab_MolecularWeight = new System.Windows.Forms.TextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.TextBox_1stRab_RefPropDLLVersion = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.TextBox_1stRab_CriticalPoint_Density = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.TextBox_1stRab_CriticalPoint_Press = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.TextBox_1stRab_CriticalPoint_Temp = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.TextBox_total_1stTab = new System.Windows.Forms.TextBox();
            this.Label_Total_1stTab = new System.Windows.Forms.Label();
            this.TextBox_R143A_FLD = new System.Windows.Forms.TextBox();
            this.TextBox_R134A_FLD = new System.Windows.Forms.TextBox();
            this.TextBox_R125_FLD = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_t_1stTab = new System.Windows.Forms.TextBox();
            this.textBox_p_1stTab = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.DataGridView_2ndTab = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.TextBox_TempPro_DewPoint = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.TextBox_TempPro_BubblePoint = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label27 = new System.Windows.Forms.Label();
            this.TextBox_TempPro_MolecularWeight = new System.Windows.Forms.TextBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.TextBox_TempPro_RefPropDLLVersion = new System.Windows.Forms.TextBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.TextBox_TempPro_CriticalPoint_Density = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.TextBox_TempPro_CriticalPoint_Press = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.TextBox_TempPro_CriticalPoint_Temp = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.TextBox_InputSheet_Total = new System.Windows.Forms.TextBox();
            this.Label_Total = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Button_TempPro_Clear = new System.Windows.Forms.Button();
            this.Button_TempPro_Calculate = new System.Windows.Forms.Button();
            this.label43 = new System.Windows.Forms.Label();
            this.TextBox_InputSheet_Nitrogen = new System.Windows.Forms.TextBox();
            this.TextBox_InputSheet_Isopentane = new System.Windows.Forms.TextBox();
            this.TextBox_InputSheet_Pentane = new System.Windows.Forms.TextBox();
            this.TextBox_InputSheet_Isobutane = new System.Windows.Forms.TextBox();
            this.TextBox_InputSheet_Butane = new System.Windows.Forms.TextBox();
            this.TextBox_InputSheet_Propane = new System.Windows.Forms.TextBox();
            this.TextBox_InputSheet_Ethane = new System.Windows.Forms.TextBox();
            this.TextBox_InputSheet_Methane = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.t_textBox_2ndTab = new System.Windows.Forms.TextBox();
            this.p_textBox_2ndTab = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.dataGridView_vapor_props = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xvap_0 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xvap_1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xvap_2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.dataGridView_liquid_props = new System.Windows.Forms.DataGridView();
            this.kph = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.p = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xliq_0 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xliq_1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.xliq_2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.comboBox_hflnme = new System.Windows.Forms.ComboBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.textBox_t_3rdTab = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel9 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.label15 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView_1st)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.panel6.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView_2ndTab)).BeginInit();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.panel8.SuspendLayout();
            this.groupBox16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_vapor_props)).BeginInit();
            this.groupBox15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_liquid_props)).BeginInit();
            this.groupBox11.SuspendLayout();
            this.panel7.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(1, 21);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(840, 312);
            this.tabControl1.TabIndex = 7;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(832, 286);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "R404A";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.panel4);
            this.groupBox2.Location = new System.Drawing.Point(297, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(539, 281);
            this.groupBox2.TabIndex = 48;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Output";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.DataGridView_1st);
            this.panel4.Controls.Add(this.groupBox5);
            this.panel4.Controls.Add(this.groupBox6);
            this.panel4.Controls.Add(this.groupBox8);
            this.panel4.Location = new System.Drawing.Point(6, 17);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(516, 258);
            this.panel4.TabIndex = 24;
            // 
            // DataGridView_1st
            // 
            this.DataGridView_1st.AllowUserToAddRows = false;
            this.DataGridView_1st.AllowUserToDeleteRows = false;
            this.DataGridView_1st.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DataGridView_1st.BackgroundColor = System.Drawing.SystemColors.Menu;
            this.DataGridView_1st.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView_1st.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            this.DataGridView_1st.Location = new System.Drawing.Point(5, 6);
            this.DataGridView_1st.Margin = new System.Windows.Forms.Padding(0);
            this.DataGridView_1st.Name = "DataGridView_1st";
            this.DataGridView_1st.ReadOnly = true;
            this.DataGridView_1st.RowHeadersVisible = false;
            this.DataGridView_1st.RowHeadersWidth = 15;
            this.DataGridView_1st.Size = new System.Drawing.Size(511, 135);
            this.DataGridView_1st.TabIndex = 19;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "    d     [mol/L]";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.ToolTipText = "Density";
            this.dataGridViewTextBoxColumn1.Width = 50;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "    Dl    [mol/L]";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.ToolTipText = "Density of Liquid";
            this.dataGridViewTextBoxColumn2.Width = 50;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "    Dv   [mol/L]";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.ToolTipText = "Density of vapor";
            this.dataGridViewTextBoxColumn3.Width = 50;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "    q ";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.ToolTipText = "Quality ((moles vapor/total moles))";
            this.dataGridViewTextBoxColumn4.Width = 50;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "    e     [J/mol]";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.ToolTipText = "Enthalpy";
            this.dataGridViewTextBoxColumn5.Width = 60;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "    h    [J/mol]";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.ToolTipText = "Gibbs (Helmholtz free energy)";
            this.dataGridViewTextBoxColumn6.Width = 60;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "    s    [J/mol-K]";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.ToolTipText = "Entropy (Heat capacity)";
            this.dataGridViewTextBoxColumn7.Width = 50;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "   Cv   [J/mol-K]";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.ToolTipText = "Isochoric heat capacity ";
            this.dataGridViewTextBoxColumn8.Width = 50;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "   Cp   [J/mol-K]";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.ToolTipText = "Isobari heat capacity";
            this.dataGridViewTextBoxColumn9.Width = 50;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.HeaderText = "    w    [m/s]";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.ToolTipText = "Speed of sound";
            this.dataGridViewTextBoxColumn10.Width = 50;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "  ierr";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.ToolTipText = "Error number";
            this.dataGridViewTextBoxColumn11.Width = 50;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.HeaderText = "    herr";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn12.ToolTipText = "Error text";
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.White;
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.TextBox_1stTab_DewPoint);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.TextBox_1stTab_BubblePoint);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(5, 141);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(239, 72);
            this.groupBox5.TabIndex = 17;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Saturation Properties";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(170, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(15, 15);
            this.label1.TabIndex = 24;
            this.label1.Text = "K";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(41, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 15);
            this.label5.TabIndex = 23;
            this.label5.Text = "Dew Point:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TextBox_1stTab_DewPoint
            // 
            this.TextBox_1stTab_DewPoint.BackColor = System.Drawing.SystemColors.Control;
            this.TextBox_1stTab_DewPoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_1stTab_DewPoint.Location = new System.Drawing.Point(114, 45);
            this.TextBox_1stTab_DewPoint.Name = "TextBox_1stTab_DewPoint";
            this.TextBox_1stTab_DewPoint.ReadOnly = true;
            this.TextBox_1stTab_DewPoint.Size = new System.Drawing.Size(50, 21);
            this.TextBox_1stTab_DewPoint.TabIndex = 22;
            this.TextBox_1stTab_DewPoint.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(170, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(15, 15);
            this.label6.TabIndex = 21;
            this.label6.Text = "K";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(26, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 15);
            this.label7.TabIndex = 20;
            this.label7.Text = "Bubble Point:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TextBox_1stTab_BubblePoint
            // 
            this.TextBox_1stTab_BubblePoint.BackColor = System.Drawing.SystemColors.Control;
            this.TextBox_1stTab_BubblePoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_1stTab_BubblePoint.Location = new System.Drawing.Point(114, 24);
            this.TextBox_1stTab_BubblePoint.Name = "TextBox_1stTab_BubblePoint";
            this.TextBox_1stTab_BubblePoint.ReadOnly = true;
            this.TextBox_1stTab_BubblePoint.Size = new System.Drawing.Size(50, 21);
            this.TextBox_1stTab_BubblePoint.TabIndex = 19;
            this.TextBox_1stTab_BubblePoint.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.White;
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Controls.Add(this.TextBox_1stTab_MolecularWeight);
            this.groupBox6.Controls.Add(this.groupBox7);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(244, 141);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(272, 72);
            this.groupBox6.TabIndex = 11;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Output Summary";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(14, 34);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 15);
            this.label8.TabIndex = 23;
            this.label8.Text = "Mol.Wt:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TextBox_1stTab_MolecularWeight
            // 
            this.TextBox_1stTab_MolecularWeight.BackColor = System.Drawing.SystemColors.Control;
            this.TextBox_1stTab_MolecularWeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_1stTab_MolecularWeight.Location = new System.Drawing.Point(63, 31);
            this.TextBox_1stTab_MolecularWeight.Name = "TextBox_1stTab_MolecularWeight";
            this.TextBox_1stTab_MolecularWeight.ReadOnly = true;
            this.TextBox_1stTab_MolecularWeight.Size = new System.Drawing.Size(92, 21);
            this.TextBox_1stTab_MolecularWeight.TabIndex = 22;
            this.TextBox_1stTab_MolecularWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.White;
            this.groupBox7.Controls.Add(this.TextBox_1stRab_RefPropDLLVersion);
            this.groupBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.Location = new System.Drawing.Point(169, 14);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(75, 46);
            this.groupBox7.TabIndex = 9;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "RefProp";
            // 
            // TextBox_1stRab_RefPropDLLVersion
            // 
            this.TextBox_1stRab_RefPropDLLVersion.BackColor = System.Drawing.SystemColors.Control;
            this.TextBox_1stRab_RefPropDLLVersion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_1stRab_RefPropDLLVersion.Location = new System.Drawing.Point(9, 17);
            this.TextBox_1stRab_RefPropDLLVersion.Name = "TextBox_1stRab_RefPropDLLVersion";
            this.TextBox_1stRab_RefPropDLLVersion.ReadOnly = true;
            this.TextBox_1stRab_RefPropDLLVersion.Size = new System.Drawing.Size(50, 21);
            this.TextBox_1stRab_RefPropDLLVersion.TabIndex = 21;
            this.TextBox_1stRab_RefPropDLLVersion.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.White;
            this.groupBox8.Controls.Add(this.panel6);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.Location = new System.Drawing.Point(4, 212);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(509, 46);
            this.groupBox8.TabIndex = 12;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Critical Point";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Controls.Add(this.label9);
            this.panel6.Controls.Add(this.label10);
            this.panel6.Controls.Add(this.TextBox_1stRab_CriticalPoint_Density);
            this.panel6.Controls.Add(this.label11);
            this.panel6.Controls.Add(this.label12);
            this.panel6.Controls.Add(this.TextBox_1stRab_CriticalPoint_Press);
            this.panel6.Controls.Add(this.label13);
            this.panel6.Controls.Add(this.label14);
            this.panel6.Controls.Add(this.TextBox_1stRab_CriticalPoint_Temp);
            this.panel6.Location = new System.Drawing.Point(49, 16);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(400, 27);
            this.panel6.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(357, 6);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 15);
            this.label9.TabIndex = 18;
            this.label9.Text = "mol/L";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(251, 7);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 15);
            this.label10.TabIndex = 17;
            this.label10.Text = "Density:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TextBox_1stRab_CriticalPoint_Density
            // 
            this.TextBox_1stRab_CriticalPoint_Density.BackColor = System.Drawing.SystemColors.Control;
            this.TextBox_1stRab_CriticalPoint_Density.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_1stRab_CriticalPoint_Density.Location = new System.Drawing.Point(305, 4);
            this.TextBox_1stRab_CriticalPoint_Density.Name = "TextBox_1stRab_CriticalPoint_Density";
            this.TextBox_1stRab_CriticalPoint_Density.ReadOnly = true;
            this.TextBox_1stRab_CriticalPoint_Density.Size = new System.Drawing.Size(50, 21);
            this.TextBox_1stRab_CriticalPoint_Density.TabIndex = 16;
            this.TextBox_1stRab_CriticalPoint_Density.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(211, 6);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(28, 15);
            this.label11.TabIndex = 15;
            this.label11.Text = "kPa";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(117, 7);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 15);
            this.label12.TabIndex = 14;
            this.label12.Text = "Press:";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TextBox_1stRab_CriticalPoint_Press
            // 
            this.TextBox_1stRab_CriticalPoint_Press.BackColor = System.Drawing.SystemColors.Control;
            this.TextBox_1stRab_CriticalPoint_Press.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_1stRab_CriticalPoint_Press.Location = new System.Drawing.Point(159, 4);
            this.TextBox_1stRab_CriticalPoint_Press.Name = "TextBox_1stRab_CriticalPoint_Press";
            this.TextBox_1stRab_CriticalPoint_Press.ReadOnly = true;
            this.TextBox_1stRab_CriticalPoint_Press.Size = new System.Drawing.Size(50, 21);
            this.TextBox_1stRab_CriticalPoint_Press.TabIndex = 13;
            this.TextBox_1stRab_CriticalPoint_Press.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(95, 7);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(15, 15);
            this.label13.TabIndex = 12;
            this.label13.Text = "K";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(2, 7);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(42, 15);
            this.label14.TabIndex = 11;
            this.label14.Text = "Temp:";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TextBox_1stRab_CriticalPoint_Temp
            // 
            this.TextBox_1stRab_CriticalPoint_Temp.BackColor = System.Drawing.SystemColors.Control;
            this.TextBox_1stRab_CriticalPoint_Temp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_1stRab_CriticalPoint_Temp.Location = new System.Drawing.Point(45, 4);
            this.TextBox_1stRab_CriticalPoint_Temp.Name = "TextBox_1stRab_CriticalPoint_Temp";
            this.TextBox_1stRab_CriticalPoint_Temp.ReadOnly = true;
            this.TextBox_1stRab_CriticalPoint_Temp.Size = new System.Drawing.Size(50, 21);
            this.TextBox_1stRab_CriticalPoint_Temp.TabIndex = 2;
            this.TextBox_1stRab_CriticalPoint_Temp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel3);
            this.groupBox1.Controls.Add(this.TextBox_total_1stTab);
            this.groupBox1.Controls.Add(this.Label_Total_1stTab);
            this.groupBox1.Controls.Add(this.TextBox_R143A_FLD);
            this.groupBox1.Controls.Add(this.TextBox_R134A_FLD);
            this.groupBox1.Controls.Add(this.TextBox_R125_FLD);
            this.groupBox1.Controls.Add(this.label37);
            this.groupBox1.Controls.Add(this.label38);
            this.groupBox1.Controls.Add(this.label39);
            this.groupBox1.Controls.Add(this.label72);
            this.groupBox1.Controls.Add(this.label68);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.textBox_t_1stTab);
            this.groupBox1.Controls.Add(this.textBox_p_1stTab);
            this.groupBox1.Location = new System.Drawing.Point(7, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(288, 281);
            this.groupBox1.TabIndex = 44;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Inputs";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.button3);
            this.panel3.Location = new System.Drawing.Point(148, 215);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(136, 65);
            this.panel3.TabIndex = 107;
            // 
            // button1
            // 
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(73, 2);
            this.button1.Margin = new System.Windows.Forms.Padding(0);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(60, 60);
            this.button1.TabIndex = 2;
            this.button1.Text = "Clear";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(4, 2);
            this.button3.Margin = new System.Windows.Forms.Padding(0);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(60, 60);
            this.button3.TabIndex = 1;
            this.button3.Text = "Calc";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // TextBox_total_1stTab
            // 
            this.TextBox_total_1stTab.BackColor = System.Drawing.Color.YellowGreen;
            this.TextBox_total_1stTab.Enabled = false;
            this.TextBox_total_1stTab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_total_1stTab.ForeColor = System.Drawing.Color.Black;
            this.TextBox_total_1stTab.Location = new System.Drawing.Point(87, 107);
            this.TextBox_total_1stTab.Name = "TextBox_total_1stTab";
            this.TextBox_total_1stTab.Size = new System.Drawing.Size(75, 21);
            this.TextBox_total_1stTab.TabIndex = 106;
            this.TextBox_total_1stTab.TabStop = false;
            this.TextBox_total_1stTab.Text = "1.0000000";
            this.TextBox_total_1stTab.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Label_Total_1stTab
            // 
            this.Label_Total_1stTab.AutoSize = true;
            this.Label_Total_1stTab.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Total_1stTab.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Label_Total_1stTab.Location = new System.Drawing.Point(45, 110);
            this.Label_Total_1stTab.Name = "Label_Total_1stTab";
            this.Label_Total_1stTab.Size = new System.Drawing.Size(37, 15);
            this.Label_Total_1stTab.TabIndex = 105;
            this.Label_Total_1stTab.Text = "Total:";
            this.Label_Total_1stTab.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TextBox_R143A_FLD
            // 
            this.TextBox_R143A_FLD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_R143A_FLD.Location = new System.Drawing.Point(87, 85);
            this.TextBox_R143A_FLD.Name = "TextBox_R143A_FLD";
            this.TextBox_R143A_FLD.Size = new System.Drawing.Size(75, 21);
            this.TextBox_R143A_FLD.TabIndex = 104;
            this.TextBox_R143A_FLD.Text = "0.6039192";
            this.TextBox_R143A_FLD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TextBox_R143A_FLD.TextChanged += new System.EventHandler(this.TextBox_R125_FLD_TextChanged);
            this.TextBox_R143A_FLD.Enter += new System.EventHandler(this.TextBox_R125_FLD_Enter);
            this.TextBox_R143A_FLD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_R125_FLD_KeyPress);
            this.TextBox_R143A_FLD.Leave += new System.EventHandler(this.TextBox_R125_FLD_Leave);
            // 
            // TextBox_R134A_FLD
            // 
            this.TextBox_R134A_FLD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_R134A_FLD.Location = new System.Drawing.Point(87, 64);
            this.TextBox_R134A_FLD.Name = "TextBox_R134A_FLD";
            this.TextBox_R134A_FLD.Size = new System.Drawing.Size(75, 21);
            this.TextBox_R134A_FLD.TabIndex = 103;
            this.TextBox_R134A_FLD.Text = "0.0382640";
            this.TextBox_R134A_FLD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TextBox_R134A_FLD.TextChanged += new System.EventHandler(this.TextBox_R125_FLD_TextChanged);
            this.TextBox_R134A_FLD.Enter += new System.EventHandler(this.TextBox_R125_FLD_Enter);
            this.TextBox_R134A_FLD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_R125_FLD_KeyPress);
            this.TextBox_R134A_FLD.Leave += new System.EventHandler(this.TextBox_R125_FLD_Leave);
            // 
            // TextBox_R125_FLD
            // 
            this.TextBox_R125_FLD.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_R125_FLD.Location = new System.Drawing.Point(88, 43);
            this.TextBox_R125_FLD.Name = "TextBox_R125_FLD";
            this.TextBox_R125_FLD.Size = new System.Drawing.Size(74, 21);
            this.TextBox_R125_FLD.TabIndex = 102;
            this.TextBox_R125_FLD.Text = "0.3578168";
            this.TextBox_R125_FLD.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TextBox_R125_FLD.TextChanged += new System.EventHandler(this.TextBox_R125_FLD_TextChanged);
            this.TextBox_R125_FLD.Enter += new System.EventHandler(this.TextBox_R125_FLD_Enter);
            this.TextBox_R125_FLD.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_R125_FLD_KeyPress);
            this.TextBox_R125_FLD.Leave += new System.EventHandler(this.TextBox_R125_FLD_Leave);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(15, 88);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(73, 15);
            this.label37.TabIndex = 101;
            this.label37.Text = "R143A.FLD:";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(15, 67);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(73, 15);
            this.label38.TabIndex = 100;
            this.label38.Text = "R134A.FLD:";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(22, 46);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(66, 15);
            this.label39.TabIndex = 99;
            this.label39.Text = "R125.FLD:";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.Location = new System.Drawing.Point(166, 162);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(28, 15);
            this.label72.TabIndex = 35;
            this.label72.Text = "kPa";
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.Location = new System.Drawing.Point(166, 142);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(15, 15);
            this.label68.TabIndex = 34;
            this.label68.Text = "K";
            this.label68.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(66, 162);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(16, 13);
            this.label3.TabIndex = 32;
            this.label3.Text = "p:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(69, 143);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(13, 13);
            this.label4.TabIndex = 32;
            this.label4.Text = "t:";
            // 
            // textBox_t_1stTab
            // 
            this.textBox_t_1stTab.Location = new System.Drawing.Point(88, 140);
            this.textBox_t_1stTab.Name = "textBox_t_1stTab";
            this.textBox_t_1stTab.Size = new System.Drawing.Size(74, 20);
            this.textBox_t_1stTab.TabIndex = 26;
            this.textBox_t_1stTab.Text = "300";
            this.textBox_t_1stTab.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBox_p_1stTab
            // 
            this.textBox_p_1stTab.Location = new System.Drawing.Point(88, 160);
            this.textBox_p_1stTab.Name = "textBox_p_1stTab";
            this.textBox_p_1stTab.Size = new System.Drawing.Size(74, 20);
            this.textBox_p_1stTab.TabIndex = 27;
            this.textBox_p_1stTab.Text = "10000";
            this.textBox_p_1stTab.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(832, 286);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Natural Gas";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.panel5);
            this.groupBox3.Location = new System.Drawing.Point(297, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(539, 281);
            this.groupBox3.TabIndex = 47;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Output";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.DataGridView_2ndTab);
            this.panel5.Controls.Add(this.groupBox10);
            this.panel5.Controls.Add(this.groupBox9);
            this.panel5.Controls.Add(this.groupBox12);
            this.panel5.Location = new System.Drawing.Point(6, 17);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(516, 258);
            this.panel5.TabIndex = 24;
            // 
            // DataGridView_2ndTab
            // 
            this.DataGridView_2ndTab.AllowUserToAddRows = false;
            this.DataGridView_2ndTab.AllowUserToDeleteRows = false;
            this.DataGridView_2ndTab.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DataGridView_2ndTab.BackgroundColor = System.Drawing.SystemColors.Menu;
            this.DataGridView_2ndTab.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridView_2ndTab.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn25,
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn28,
            this.dataGridViewTextBoxColumn29,
            this.dataGridViewTextBoxColumn30,
            this.dataGridViewTextBoxColumn31,
            this.dataGridViewTextBoxColumn32,
            this.dataGridViewTextBoxColumn33,
            this.dataGridViewTextBoxColumn34});
            this.DataGridView_2ndTab.Location = new System.Drawing.Point(3, 2);
            this.DataGridView_2ndTab.Margin = new System.Windows.Forms.Padding(0);
            this.DataGridView_2ndTab.Name = "DataGridView_2ndTab";
            this.DataGridView_2ndTab.ReadOnly = true;
            this.DataGridView_2ndTab.RowHeadersVisible = false;
            this.DataGridView_2ndTab.RowHeadersWidth = 15;
            this.DataGridView_2ndTab.Size = new System.Drawing.Size(511, 150);
            this.DataGridView_2ndTab.TabIndex = 20;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.HeaderText = "    d     [mol/L]";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            this.dataGridViewTextBoxColumn21.ToolTipText = "Density";
            this.dataGridViewTextBoxColumn21.Width = 50;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.HeaderText = "    Dl    [mol/L]";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            this.dataGridViewTextBoxColumn22.ToolTipText = "Density of Liquid";
            this.dataGridViewTextBoxColumn22.Width = 50;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.HeaderText = "    Dv   [mol/L]";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.ReadOnly = true;
            this.dataGridViewTextBoxColumn25.ToolTipText = "Density of vapor";
            this.dataGridViewTextBoxColumn25.Width = 50;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.HeaderText = "    q ";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.ReadOnly = true;
            this.dataGridViewTextBoxColumn26.ToolTipText = "Quality ((moles vapor/total moles))";
            this.dataGridViewTextBoxColumn26.Width = 50;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.HeaderText = "    e     [J/mol]";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.ReadOnly = true;
            this.dataGridViewTextBoxColumn27.ToolTipText = "Enthalpy";
            this.dataGridViewTextBoxColumn27.Width = 60;
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.HeaderText = "    h    [J/mol]";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            this.dataGridViewTextBoxColumn28.ReadOnly = true;
            this.dataGridViewTextBoxColumn28.ToolTipText = "Gibbs (Helmholtz free energy)";
            this.dataGridViewTextBoxColumn28.Width = 60;
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.HeaderText = "    s    [J/mol-K]";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            this.dataGridViewTextBoxColumn29.ReadOnly = true;
            this.dataGridViewTextBoxColumn29.ToolTipText = "Entropy (Heat capacity)";
            this.dataGridViewTextBoxColumn29.Width = 50;
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.HeaderText = "    Cv    [J/mol-K]";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.ReadOnly = true;
            this.dataGridViewTextBoxColumn30.ToolTipText = "Isochoric heat capacity ";
            this.dataGridViewTextBoxColumn30.Width = 50;
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.HeaderText = "    Cp    [J/mol-K]";
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.ReadOnly = true;
            this.dataGridViewTextBoxColumn31.ToolTipText = "Isobari heat capacity";
            this.dataGridViewTextBoxColumn31.Width = 50;
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.HeaderText = "   w    [m/s]";
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            this.dataGridViewTextBoxColumn32.ReadOnly = true;
            this.dataGridViewTextBoxColumn32.ToolTipText = "Speed of sound";
            this.dataGridViewTextBoxColumn32.Width = 50;
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.HeaderText = "   ierr";
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            this.dataGridViewTextBoxColumn33.ReadOnly = true;
            this.dataGridViewTextBoxColumn33.ToolTipText = "Error number";
            this.dataGridViewTextBoxColumn33.Width = 50;
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.HeaderText = "   herr";
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            this.dataGridViewTextBoxColumn34.ReadOnly = true;
            this.dataGridViewTextBoxColumn34.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn34.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn34.ToolTipText = "Error text";
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.Color.White;
            this.groupBox10.Controls.Add(this.label33);
            this.groupBox10.Controls.Add(this.label34);
            this.groupBox10.Controls.Add(this.TextBox_TempPro_DewPoint);
            this.groupBox10.Controls.Add(this.label31);
            this.groupBox10.Controls.Add(this.label32);
            this.groupBox10.Controls.Add(this.TextBox_TempPro_BubblePoint);
            this.groupBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.Location = new System.Drawing.Point(5, 152);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(239, 63);
            this.groupBox10.TabIndex = 17;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Saturation Properties";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(170, 40);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(15, 15);
            this.label33.TabIndex = 24;
            this.label33.Text = "K";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(42, 38);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(66, 15);
            this.label34.TabIndex = 23;
            this.label34.Text = "Dew Point:";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TextBox_TempPro_DewPoint
            // 
            this.TextBox_TempPro_DewPoint.BackColor = System.Drawing.SystemColors.Control;
            this.TextBox_TempPro_DewPoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_TempPro_DewPoint.Location = new System.Drawing.Point(115, 36);
            this.TextBox_TempPro_DewPoint.Name = "TextBox_TempPro_DewPoint";
            this.TextBox_TempPro_DewPoint.ReadOnly = true;
            this.TextBox_TempPro_DewPoint.Size = new System.Drawing.Size(50, 21);
            this.TextBox_TempPro_DewPoint.TabIndex = 22;
            this.TextBox_TempPro_DewPoint.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(171, 18);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(15, 15);
            this.label31.TabIndex = 21;
            this.label31.Text = "K";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(27, 18);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(80, 15);
            this.label32.TabIndex = 20;
            this.label32.Text = "Bubble Point:";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TextBox_TempPro_BubblePoint
            // 
            this.TextBox_TempPro_BubblePoint.BackColor = System.Drawing.SystemColors.Control;
            this.TextBox_TempPro_BubblePoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_TempPro_BubblePoint.Location = new System.Drawing.Point(115, 15);
            this.TextBox_TempPro_BubblePoint.Name = "TextBox_TempPro_BubblePoint";
            this.TextBox_TempPro_BubblePoint.ReadOnly = true;
            this.TextBox_TempPro_BubblePoint.Size = new System.Drawing.Size(50, 21);
            this.TextBox_TempPro_BubblePoint.TabIndex = 19;
            this.TextBox_TempPro_BubblePoint.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.Color.White;
            this.groupBox9.Controls.Add(this.label27);
            this.groupBox9.Controls.Add(this.TextBox_TempPro_MolecularWeight);
            this.groupBox9.Controls.Add(this.groupBox14);
            this.groupBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.Location = new System.Drawing.Point(244, 152);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(272, 63);
            this.groupBox9.TabIndex = 11;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Output Summary";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(14, 29);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(48, 15);
            this.label27.TabIndex = 23;
            this.label27.Text = "Mol.Wt:";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TextBox_TempPro_MolecularWeight
            // 
            this.TextBox_TempPro_MolecularWeight.BackColor = System.Drawing.SystemColors.Control;
            this.TextBox_TempPro_MolecularWeight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_TempPro_MolecularWeight.Location = new System.Drawing.Point(63, 26);
            this.TextBox_TempPro_MolecularWeight.Name = "TextBox_TempPro_MolecularWeight";
            this.TextBox_TempPro_MolecularWeight.ReadOnly = true;
            this.TextBox_TempPro_MolecularWeight.Size = new System.Drawing.Size(92, 21);
            this.TextBox_TempPro_MolecularWeight.TabIndex = 22;
            this.TextBox_TempPro_MolecularWeight.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox14
            // 
            this.groupBox14.BackColor = System.Drawing.Color.White;
            this.groupBox14.Controls.Add(this.TextBox_TempPro_RefPropDLLVersion);
            this.groupBox14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox14.Location = new System.Drawing.Point(169, 9);
            this.groupBox14.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(75, 46);
            this.groupBox14.TabIndex = 9;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "RefProp";
            // 
            // TextBox_TempPro_RefPropDLLVersion
            // 
            this.TextBox_TempPro_RefPropDLLVersion.BackColor = System.Drawing.SystemColors.Control;
            this.TextBox_TempPro_RefPropDLLVersion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_TempPro_RefPropDLLVersion.Location = new System.Drawing.Point(9, 17);
            this.TextBox_TempPro_RefPropDLLVersion.Name = "TextBox_TempPro_RefPropDLLVersion";
            this.TextBox_TempPro_RefPropDLLVersion.ReadOnly = true;
            this.TextBox_TempPro_RefPropDLLVersion.Size = new System.Drawing.Size(50, 21);
            this.TextBox_TempPro_RefPropDLLVersion.TabIndex = 21;
            this.TextBox_TempPro_RefPropDLLVersion.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox12
            // 
            this.groupBox12.BackColor = System.Drawing.Color.White;
            this.groupBox12.Controls.Add(this.panel1);
            this.groupBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox12.Location = new System.Drawing.Point(4, 213);
            this.groupBox12.Margin = new System.Windows.Forms.Padding(0);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(509, 45);
            this.groupBox12.TabIndex = 12;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Critical Point";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.label29);
            this.panel1.Controls.Add(this.label30);
            this.panel1.Controls.Add(this.TextBox_TempPro_CriticalPoint_Density);
            this.panel1.Controls.Add(this.label41);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Controls.Add(this.TextBox_TempPro_CriticalPoint_Press);
            this.panel1.Controls.Add(this.label46);
            this.panel1.Controls.Add(this.label47);
            this.panel1.Controls.Add(this.TextBox_TempPro_CriticalPoint_Temp);
            this.panel1.Location = new System.Drawing.Point(49, 15);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(400, 27);
            this.panel1.TabIndex = 1;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(357, 6);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(38, 15);
            this.label29.TabIndex = 18;
            this.label29.Text = "mol/L";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(251, 7);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(50, 15);
            this.label30.TabIndex = 17;
            this.label30.Text = "Density:";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TextBox_TempPro_CriticalPoint_Density
            // 
            this.TextBox_TempPro_CriticalPoint_Density.BackColor = System.Drawing.SystemColors.Control;
            this.TextBox_TempPro_CriticalPoint_Density.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_TempPro_CriticalPoint_Density.Location = new System.Drawing.Point(305, 4);
            this.TextBox_TempPro_CriticalPoint_Density.Name = "TextBox_TempPro_CriticalPoint_Density";
            this.TextBox_TempPro_CriticalPoint_Density.ReadOnly = true;
            this.TextBox_TempPro_CriticalPoint_Density.Size = new System.Drawing.Size(50, 21);
            this.TextBox_TempPro_CriticalPoint_Density.TabIndex = 16;
            this.TextBox_TempPro_CriticalPoint_Density.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(211, 6);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(28, 15);
            this.label41.TabIndex = 15;
            this.label41.Text = "kPa";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(117, 7);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(41, 15);
            this.label45.TabIndex = 14;
            this.label45.Text = "Press:";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TextBox_TempPro_CriticalPoint_Press
            // 
            this.TextBox_TempPro_CriticalPoint_Press.BackColor = System.Drawing.SystemColors.Control;
            this.TextBox_TempPro_CriticalPoint_Press.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_TempPro_CriticalPoint_Press.Location = new System.Drawing.Point(159, 4);
            this.TextBox_TempPro_CriticalPoint_Press.Name = "TextBox_TempPro_CriticalPoint_Press";
            this.TextBox_TempPro_CriticalPoint_Press.ReadOnly = true;
            this.TextBox_TempPro_CriticalPoint_Press.Size = new System.Drawing.Size(50, 21);
            this.TextBox_TempPro_CriticalPoint_Press.TabIndex = 13;
            this.TextBox_TempPro_CriticalPoint_Press.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(95, 7);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(15, 15);
            this.label46.TabIndex = 12;
            this.label46.Text = "K";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(2, 7);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(42, 15);
            this.label47.TabIndex = 11;
            this.label47.Text = "Temp:";
            this.label47.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TextBox_TempPro_CriticalPoint_Temp
            // 
            this.TextBox_TempPro_CriticalPoint_Temp.BackColor = System.Drawing.SystemColors.Control;
            this.TextBox_TempPro_CriticalPoint_Temp.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_TempPro_CriticalPoint_Temp.Location = new System.Drawing.Point(45, 4);
            this.TextBox_TempPro_CriticalPoint_Temp.Name = "TextBox_TempPro_CriticalPoint_Temp";
            this.TextBox_TempPro_CriticalPoint_Temp.ReadOnly = true;
            this.TextBox_TempPro_CriticalPoint_Temp.Size = new System.Drawing.Size(50, 21);
            this.TextBox_TempPro_CriticalPoint_Temp.TabIndex = 2;
            this.TextBox_TempPro_CriticalPoint_Temp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.TextBox_InputSheet_Total);
            this.groupBox4.Controls.Add(this.Label_Total);
            this.groupBox4.Controls.Add(this.label42);
            this.groupBox4.Controls.Add(this.panel2);
            this.groupBox4.Controls.Add(this.label43);
            this.groupBox4.Controls.Add(this.TextBox_InputSheet_Nitrogen);
            this.groupBox4.Controls.Add(this.TextBox_InputSheet_Isopentane);
            this.groupBox4.Controls.Add(this.TextBox_InputSheet_Pentane);
            this.groupBox4.Controls.Add(this.TextBox_InputSheet_Isobutane);
            this.groupBox4.Controls.Add(this.TextBox_InputSheet_Butane);
            this.groupBox4.Controls.Add(this.TextBox_InputSheet_Propane);
            this.groupBox4.Controls.Add(this.TextBox_InputSheet_Ethane);
            this.groupBox4.Controls.Add(this.TextBox_InputSheet_Methane);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.label19);
            this.groupBox4.Controls.Add(this.label20);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.label22);
            this.groupBox4.Controls.Add(this.label23);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.label25);
            this.groupBox4.Controls.Add(this.label50);
            this.groupBox4.Controls.Add(this.label51);
            this.groupBox4.Controls.Add(this.t_textBox_2ndTab);
            this.groupBox4.Controls.Add(this.p_textBox_2ndTab);
            this.groupBox4.Location = new System.Drawing.Point(7, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(288, 281);
            this.groupBox4.TabIndex = 46;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Inputs";
            // 
            // TextBox_InputSheet_Total
            // 
            this.TextBox_InputSheet_Total.BackColor = System.Drawing.Color.YellowGreen;
            this.TextBox_InputSheet_Total.Enabled = false;
            this.TextBox_InputSheet_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_InputSheet_Total.ForeColor = System.Drawing.Color.Black;
            this.TextBox_InputSheet_Total.Location = new System.Drawing.Point(75, 187);
            this.TextBox_InputSheet_Total.Name = "TextBox_InputSheet_Total";
            this.TextBox_InputSheet_Total.Size = new System.Drawing.Size(75, 21);
            this.TextBox_InputSheet_Total.TabIndex = 98;
            this.TextBox_InputSheet_Total.TabStop = false;
            this.TextBox_InputSheet_Total.Text = "1.0000000";
            this.TextBox_InputSheet_Total.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Label_Total
            // 
            this.Label_Total.AutoSize = true;
            this.Label_Total.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_Total.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Label_Total.Location = new System.Drawing.Point(30, 189);
            this.Label_Total.Name = "Label_Total";
            this.Label_Total.Size = new System.Drawing.Size(37, 15);
            this.Label_Total.TabIndex = 97;
            this.Label_Total.Text = "Total:";
            this.Label_Total.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(246, 109);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(28, 15);
            this.label42.TabIndex = 96;
            this.label42.Text = "kPa";
            this.label42.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.Button_TempPro_Clear);
            this.panel2.Controls.Add(this.Button_TempPro_Calculate);
            this.panel2.Location = new System.Drawing.Point(148, 215);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(136, 65);
            this.panel2.TabIndex = 14;
            // 
            // Button_TempPro_Clear
            // 
            this.Button_TempPro_Clear.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Button_TempPro_Clear.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_TempPro_Clear.Location = new System.Drawing.Point(73, 2);
            this.Button_TempPro_Clear.Margin = new System.Windows.Forms.Padding(0);
            this.Button_TempPro_Clear.Name = "Button_TempPro_Clear";
            this.Button_TempPro_Clear.Size = new System.Drawing.Size(60, 60);
            this.Button_TempPro_Clear.TabIndex = 2;
            this.Button_TempPro_Clear.Text = "Clear";
            this.Button_TempPro_Clear.UseVisualStyleBackColor = true;
            this.Button_TempPro_Clear.Click += new System.EventHandler(this.Button_TempPro_Clear_Click);
            // 
            // Button_TempPro_Calculate
            // 
            this.Button_TempPro_Calculate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Button_TempPro_Calculate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_TempPro_Calculate.Location = new System.Drawing.Point(4, 2);
            this.Button_TempPro_Calculate.Margin = new System.Windows.Forms.Padding(0);
            this.Button_TempPro_Calculate.Name = "Button_TempPro_Calculate";
            this.Button_TempPro_Calculate.Size = new System.Drawing.Size(60, 60);
            this.Button_TempPro_Calculate.TabIndex = 1;
            this.Button_TempPro_Calculate.Text = "Calc";
            this.Button_TempPro_Calculate.UseVisualStyleBackColor = true;
            this.Button_TempPro_Calculate.Click += new System.EventHandler(this.Button_TempPro_Calculate_Click);
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(246, 90);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(15, 15);
            this.label43.TabIndex = 95;
            this.label43.Text = "K";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // TextBox_InputSheet_Nitrogen
            // 
            this.TextBox_InputSheet_Nitrogen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_InputSheet_Nitrogen.Location = new System.Drawing.Point(75, 165);
            this.TextBox_InputSheet_Nitrogen.Name = "TextBox_InputSheet_Nitrogen";
            this.TextBox_InputSheet_Nitrogen.Size = new System.Drawing.Size(75, 21);
            this.TextBox_InputSheet_Nitrogen.TabIndex = 94;
            this.TextBox_InputSheet_Nitrogen.Text = "0.0000000";
            this.TextBox_InputSheet_Nitrogen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TextBox_InputSheet_Nitrogen.TextChanged += new System.EventHandler(this.TextBox_InputSheet_Methane_TextChanged);
            this.TextBox_InputSheet_Nitrogen.Enter += new System.EventHandler(this.TextBox_InputSheet_Methane_Enter);
            this.TextBox_InputSheet_Nitrogen.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_InputSheet_Methane_KeyPress);
            this.TextBox_InputSheet_Nitrogen.Leave += new System.EventHandler(this.TextBox_InputSheet_Methane_Leave);
            // 
            // TextBox_InputSheet_Isopentane
            // 
            this.TextBox_InputSheet_Isopentane.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_InputSheet_Isopentane.Location = new System.Drawing.Point(75, 144);
            this.TextBox_InputSheet_Isopentane.Name = "TextBox_InputSheet_Isopentane";
            this.TextBox_InputSheet_Isopentane.Size = new System.Drawing.Size(75, 21);
            this.TextBox_InputSheet_Isopentane.TabIndex = 93;
            this.TextBox_InputSheet_Isopentane.Text = "0.0000000";
            this.TextBox_InputSheet_Isopentane.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TextBox_InputSheet_Isopentane.TextChanged += new System.EventHandler(this.TextBox_InputSheet_Methane_TextChanged);
            this.TextBox_InputSheet_Isopentane.Enter += new System.EventHandler(this.TextBox_InputSheet_Methane_Enter);
            this.TextBox_InputSheet_Isopentane.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_InputSheet_Methane_KeyPress);
            this.TextBox_InputSheet_Isopentane.Leave += new System.EventHandler(this.TextBox_InputSheet_Methane_Leave);
            // 
            // TextBox_InputSheet_Pentane
            // 
            this.TextBox_InputSheet_Pentane.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_InputSheet_Pentane.Location = new System.Drawing.Point(75, 124);
            this.TextBox_InputSheet_Pentane.Name = "TextBox_InputSheet_Pentane";
            this.TextBox_InputSheet_Pentane.Size = new System.Drawing.Size(75, 21);
            this.TextBox_InputSheet_Pentane.TabIndex = 92;
            this.TextBox_InputSheet_Pentane.Text = "0.0000000";
            this.TextBox_InputSheet_Pentane.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TextBox_InputSheet_Pentane.TextChanged += new System.EventHandler(this.TextBox_InputSheet_Methane_TextChanged);
            this.TextBox_InputSheet_Pentane.Enter += new System.EventHandler(this.TextBox_InputSheet_Methane_Enter);
            this.TextBox_InputSheet_Pentane.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_InputSheet_Methane_KeyPress);
            this.TextBox_InputSheet_Pentane.Leave += new System.EventHandler(this.TextBox_InputSheet_Methane_Leave);
            // 
            // TextBox_InputSheet_Isobutane
            // 
            this.TextBox_InputSheet_Isobutane.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_InputSheet_Isobutane.Location = new System.Drawing.Point(75, 103);
            this.TextBox_InputSheet_Isobutane.Name = "TextBox_InputSheet_Isobutane";
            this.TextBox_InputSheet_Isobutane.Size = new System.Drawing.Size(75, 21);
            this.TextBox_InputSheet_Isobutane.TabIndex = 91;
            this.TextBox_InputSheet_Isobutane.Text = "0.0000000";
            this.TextBox_InputSheet_Isobutane.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TextBox_InputSheet_Isobutane.TextChanged += new System.EventHandler(this.TextBox_InputSheet_Methane_TextChanged);
            this.TextBox_InputSheet_Isobutane.Enter += new System.EventHandler(this.TextBox_InputSheet_Methane_Enter);
            this.TextBox_InputSheet_Isobutane.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_InputSheet_Methane_KeyPress);
            this.TextBox_InputSheet_Isobutane.Leave += new System.EventHandler(this.TextBox_InputSheet_Methane_Leave);
            // 
            // TextBox_InputSheet_Butane
            // 
            this.TextBox_InputSheet_Butane.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_InputSheet_Butane.Location = new System.Drawing.Point(75, 82);
            this.TextBox_InputSheet_Butane.Name = "TextBox_InputSheet_Butane";
            this.TextBox_InputSheet_Butane.Size = new System.Drawing.Size(75, 21);
            this.TextBox_InputSheet_Butane.TabIndex = 90;
            this.TextBox_InputSheet_Butane.Text = "0.0000000";
            this.TextBox_InputSheet_Butane.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TextBox_InputSheet_Butane.TextChanged += new System.EventHandler(this.TextBox_InputSheet_Methane_TextChanged);
            this.TextBox_InputSheet_Butane.Enter += new System.EventHandler(this.TextBox_InputSheet_Methane_Enter);
            this.TextBox_InputSheet_Butane.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_InputSheet_Methane_KeyPress);
            this.TextBox_InputSheet_Butane.Leave += new System.EventHandler(this.TextBox_InputSheet_Methane_Leave);
            // 
            // TextBox_InputSheet_Propane
            // 
            this.TextBox_InputSheet_Propane.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_InputSheet_Propane.Location = new System.Drawing.Point(75, 61);
            this.TextBox_InputSheet_Propane.Name = "TextBox_InputSheet_Propane";
            this.TextBox_InputSheet_Propane.Size = new System.Drawing.Size(75, 21);
            this.TextBox_InputSheet_Propane.TabIndex = 89;
            this.TextBox_InputSheet_Propane.Text = "0.0000000";
            this.TextBox_InputSheet_Propane.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TextBox_InputSheet_Propane.TextChanged += new System.EventHandler(this.TextBox_InputSheet_Methane_TextChanged);
            this.TextBox_InputSheet_Propane.Enter += new System.EventHandler(this.TextBox_InputSheet_Methane_Enter);
            this.TextBox_InputSheet_Propane.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_InputSheet_Methane_KeyPress);
            this.TextBox_InputSheet_Propane.Leave += new System.EventHandler(this.TextBox_InputSheet_Methane_Leave);
            // 
            // TextBox_InputSheet_Ethane
            // 
            this.TextBox_InputSheet_Ethane.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_InputSheet_Ethane.Location = new System.Drawing.Point(75, 40);
            this.TextBox_InputSheet_Ethane.Name = "TextBox_InputSheet_Ethane";
            this.TextBox_InputSheet_Ethane.Size = new System.Drawing.Size(75, 21);
            this.TextBox_InputSheet_Ethane.TabIndex = 88;
            this.TextBox_InputSheet_Ethane.Text = "0.0000000";
            this.TextBox_InputSheet_Ethane.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TextBox_InputSheet_Ethane.TextChanged += new System.EventHandler(this.TextBox_InputSheet_Methane_TextChanged);
            this.TextBox_InputSheet_Ethane.Enter += new System.EventHandler(this.TextBox_InputSheet_Methane_Enter);
            this.TextBox_InputSheet_Ethane.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_InputSheet_Methane_KeyPress);
            this.TextBox_InputSheet_Ethane.Leave += new System.EventHandler(this.TextBox_InputSheet_Methane_Leave);
            // 
            // TextBox_InputSheet_Methane
            // 
            this.TextBox_InputSheet_Methane.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBox_InputSheet_Methane.Location = new System.Drawing.Point(76, 19);
            this.TextBox_InputSheet_Methane.Name = "TextBox_InputSheet_Methane";
            this.TextBox_InputSheet_Methane.Size = new System.Drawing.Size(74, 21);
            this.TextBox_InputSheet_Methane.TabIndex = 87;
            this.TextBox_InputSheet_Methane.Text = "1.0000000";
            this.TextBox_InputSheet_Methane.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TextBox_InputSheet_Methane.TextChanged += new System.EventHandler(this.TextBox_InputSheet_Methane_TextChanged);
            this.TextBox_InputSheet_Methane.Enter += new System.EventHandler(this.TextBox_InputSheet_Methane_Enter);
            this.TextBox_InputSheet_Methane.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TextBox_InputSheet_Methane_KeyPress);
            this.TextBox_InputSheet_Methane.Leave += new System.EventHandler(this.TextBox_InputSheet_Methane_Leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(10, 170);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 15);
            this.label2.TabIndex = 86;
            this.label2.Text = "Nitrogen:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(-4, 149);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(71, 15);
            this.label19.TabIndex = 85;
            this.label19.Text = "Isopentane:";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(11, 130);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(56, 15);
            this.label20.TabIndex = 84;
            this.label20.Text = "Pentane:";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(3, 108);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(64, 15);
            this.label21.TabIndex = 83;
            this.label21.Text = "Isobutane:";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(18, 86);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(49, 15);
            this.label22.TabIndex = 82;
            this.label22.Text = "Butane:";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(13, 62);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(57, 15);
            this.label23.TabIndex = 81;
            this.label23.Text = "Propane:";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(21, 40);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(49, 15);
            this.label24.TabIndex = 80;
            this.label24.Text = "Ethane:";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(11, 19);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(59, 15);
            this.label25.TabIndex = 79;
            this.label25.Text = "Methane:";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(161, 109);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(16, 13);
            this.label50.TabIndex = 32;
            this.label50.Text = "p:";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(161, 89);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(13, 13);
            this.label51.TabIndex = 32;
            this.label51.Text = "t:";
            // 
            // t_textBox_2ndTab
            // 
            this.t_textBox_2ndTab.Location = new System.Drawing.Point(180, 86);
            this.t_textBox_2ndTab.Name = "t_textBox_2ndTab";
            this.t_textBox_2ndTab.Size = new System.Drawing.Size(60, 20);
            this.t_textBox_2ndTab.TabIndex = 26;
            this.t_textBox_2ndTab.Text = "300";
            this.t_textBox_2ndTab.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // p_textBox_2ndTab
            // 
            this.p_textBox_2ndTab.Location = new System.Drawing.Point(180, 107);
            this.p_textBox_2ndTab.Name = "p_textBox_2ndTab";
            this.p_textBox_2ndTab.Size = new System.Drawing.Size(60, 20);
            this.p_textBox_2ndTab.TabIndex = 27;
            this.p_textBox_2ndTab.Text = "10000";
            this.p_textBox_2ndTab.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox13);
            this.tabPage3.Controls.Add(this.groupBox11);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(832, 286);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "EX-MIX-FORTRAN";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.panel8);
            this.groupBox13.Location = new System.Drawing.Point(182, 3);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(641, 281);
            this.groupBox13.TabIndex = 48;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Output";
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.groupBox16);
            this.panel8.Controls.Add(this.groupBox15);
            this.panel8.Location = new System.Drawing.Point(6, 17);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(664, 258);
            this.panel8.TabIndex = 24;
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.dataGridView_vapor_props);
            this.groupBox16.Location = new System.Drawing.Point(0, 128);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(632, 128);
            this.groupBox16.TabIndex = 50;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Saturated VAPOR Properties";
            // 
            // dataGridView_vapor_props
            // 
            this.dataGridView_vapor_props.AllowUserToAddRows = false;
            this.dataGridView_vapor_props.AllowUserToDeleteRows = false;
            this.dataGridView_vapor_props.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_vapor_props.BackgroundColor = System.Drawing.SystemColors.Menu;
            this.dataGridView_vapor_props.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_vapor_props.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.xvap_0,
            this.xvap_1,
            this.xvap_2,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20});
            this.dataGridView_vapor_props.Location = new System.Drawing.Point(3, 14);
            this.dataGridView_vapor_props.Margin = new System.Windows.Forms.Padding(0);
            this.dataGridView_vapor_props.Name = "dataGridView_vapor_props";
            this.dataGridView_vapor_props.ReadOnly = true;
            this.dataGridView_vapor_props.RowHeadersVisible = false;
            this.dataGridView_vapor_props.RowHeadersWidth = 15;
            this.dataGridView_vapor_props.Size = new System.Drawing.Size(626, 109);
            this.dataGridView_vapor_props.TabIndex = 19;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.HeaderText = "    kph";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.ToolTipText = "Phase flag (1 =Liquid, 2= Vapor)";
            this.dataGridViewTextBoxColumn13.Width = 50;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.HeaderText = "          p                   [kPa]";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.ToolTipText = "Pressure";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.HeaderText = "          Dl                   [mol/L]";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.ToolTipText = "Density of liquid";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.HeaderText = "          Dv                 [mol/L]";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            this.dataGridViewTextBoxColumn18.ToolTipText = "Density of vapor";
            // 
            // xvap_0
            // 
            this.xvap_0.HeaderText = "xvap[0]";
            this.xvap_0.Name = "xvap_0";
            this.xvap_0.ReadOnly = true;
            // 
            // xvap_1
            // 
            this.xvap_1.HeaderText = "xvap[1]";
            this.xvap_1.Name = "xvap_1";
            this.xvap_1.ReadOnly = true;
            // 
            // xvap_2
            // 
            this.xvap_2.HeaderText = "xvap[2]";
            this.xvap_2.Name = "xvap_2";
            this.xvap_2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.HeaderText = "ierr";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.ToolTipText = "Error Number";
            this.dataGridViewTextBoxColumn19.Width = 50;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.HeaderText = "herr";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn20.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn20.ToolTipText = "Error text";
            this.dataGridViewTextBoxColumn20.Width = 200;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.dataGridView_liquid_props);
            this.groupBox15.Location = new System.Drawing.Point(0, 3);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(632, 128);
            this.groupBox15.TabIndex = 48;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Saturated LIQUID Properties";
            // 
            // dataGridView_liquid_props
            // 
            this.dataGridView_liquid_props.AllowUserToAddRows = false;
            this.dataGridView_liquid_props.AllowUserToDeleteRows = false;
            this.dataGridView_liquid_props.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView_liquid_props.BackgroundColor = System.Drawing.SystemColors.Menu;
            this.dataGridView_liquid_props.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_liquid_props.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.kph,
            this.p,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.xliq_0,
            this.xliq_1,
            this.xliq_2,
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn24});
            this.dataGridView_liquid_props.Location = new System.Drawing.Point(3, 16);
            this.dataGridView_liquid_props.Margin = new System.Windows.Forms.Padding(0);
            this.dataGridView_liquid_props.Name = "dataGridView_liquid_props";
            this.dataGridView_liquid_props.ReadOnly = true;
            this.dataGridView_liquid_props.RowHeadersVisible = false;
            this.dataGridView_liquid_props.RowHeadersWidth = 15;
            this.dataGridView_liquid_props.Size = new System.Drawing.Size(626, 109);
            this.dataGridView_liquid_props.TabIndex = 18;
            // 
            // kph
            // 
            this.kph.HeaderText = "   kph";
            this.kph.Name = "kph";
            this.kph.ReadOnly = true;
            this.kph.ToolTipText = "Phase flag (1 =Liquid, 2= Vapor)";
            this.kph.Width = 50;
            // 
            // p
            // 
            this.p.HeaderText = "          p                   [kPa]";
            this.p.Name = "p";
            this.p.ReadOnly = true;
            this.p.ToolTipText = "Pressure";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.HeaderText = "          Dl                   [mol/L]";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.ToolTipText = "Density of liquid";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.HeaderText = "          Dv                 [mol/L]";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.ToolTipText = "Density of vapor";
            // 
            // xliq_0
            // 
            this.xliq_0.HeaderText = "xliq[0]";
            this.xliq_0.Name = "xliq_0";
            this.xliq_0.ReadOnly = true;
            // 
            // xliq_1
            // 
            this.xliq_1.HeaderText = "xliq[1]";
            this.xliq_1.Name = "xliq_1";
            this.xliq_1.ReadOnly = true;
            // 
            // xliq_2
            // 
            this.xliq_2.HeaderText = "xliq[2]";
            this.xliq_2.Name = "xliq_2";
            this.xliq_2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.HeaderText = "ierr";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            this.dataGridViewTextBoxColumn23.ToolTipText = "Error Number";
            this.dataGridViewTextBoxColumn23.Width = 50;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.HeaderText = "herr";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            this.dataGridViewTextBoxColumn24.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn24.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn24.ToolTipText = "Error text";
            this.dataGridViewTextBoxColumn24.Width = 200;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.comboBox_hflnme);
            this.groupBox11.Controls.Add(this.panel7);
            this.groupBox11.Controls.Add(this.label17);
            this.groupBox11.Controls.Add(this.label49);
            this.groupBox11.Controls.Add(this.label52);
            this.groupBox11.Controls.Add(this.textBox_t_3rdTab);
            this.groupBox11.Location = new System.Drawing.Point(6, 2);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(170, 281);
            this.groupBox11.TabIndex = 47;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Inputs";
            // 
            // comboBox_hflnme
            // 
            this.comboBox_hflnme.FormattingEnabled = true;
            this.comboBox_hflnme.Items.AddRange(new object[] {
            "R401A",
            "R401B",
            "R401C",
            "R402A",
            "R402B",
            "R403A",
            "R403B",
            "R404A",
            "R405A",
            "R406A",
            "R407A",
            "R407B",
            "R407C",
            "R407D",
            "R407E",
            "R407F",
            "ERROR"});
            this.comboBox_hflnme.Location = new System.Drawing.Point(47, 102);
            this.comboBox_hflnme.Name = "comboBox_hflnme";
            this.comboBox_hflnme.Size = new System.Drawing.Size(96, 21);
            this.comboBox_hflnme.TabIndex = 96;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.button4);
            this.panel7.Controls.Add(this.button5);
            this.panel7.Location = new System.Drawing.Point(15, 210);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(136, 65);
            this.panel7.TabIndex = 14;
            // 
            // button4
            // 
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(73, 2);
            this.button4.Margin = new System.Windows.Forms.Padding(0);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(60, 60);
            this.button4.TabIndex = 2;
            this.button4.Text = " Clear";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(4, 2);
            this.button5.Margin = new System.Windows.Forms.Padding(0);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(60, 60);
            this.button5.TabIndex = 1;
            this.button5.Text = "Calc";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(110, 83);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(15, 15);
            this.label17.TabIndex = 95;
            this.label17.Text = "K";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(7, 105);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(44, 13);
            this.label49.TabIndex = 32;
            this.label49.Text = "Mixture:";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(28, 84);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(13, 13);
            this.label52.TabIndex = 32;
            this.label52.Text = "t:";
            // 
            // textBox_t_3rdTab
            // 
            this.textBox_t_3rdTab.Location = new System.Drawing.Point(47, 81);
            this.textBox_t_3rdTab.Name = "textBox_t_3rdTab";
            this.textBox_t_3rdTab.Size = new System.Drawing.Size(60, 20);
            this.textBox_t_3rdTab.TabIndex = 26;
            this.textBox_t_3rdTab.Text = "100";
            this.textBox_t_3rdTab.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(839, 24);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.button2);
            this.panel9.Controls.Add(this.label16);
            this.panel9.Controls.Add(this.linkLabel2);
            this.panel9.Controls.Add(this.linkLabel1);
            this.panel9.Controls.Add(this.label15);
            this.panel9.Location = new System.Drawing.Point(121, 104);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(597, 124);
            this.panel9.TabIndex = 12;
            this.panel9.Visible = false;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(549, 93);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(41, 23);
            this.button2.TabIndex = 12;
            this.button2.Text = "Close";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_2);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(10, 102);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(79, 13);
            this.label16.TabIndex = 3;
            this.label16.Text = "(847) 590-5686";
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Location = new System.Drawing.Point(10, 85);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(154, 13);
            this.linkLabel2.TabIndex = 2;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "support@millcreeksystems.com";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(10, 68);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(135, 13);
            this.linkLabel1.TabIndex = 1;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "www.millcreeksystems.com";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(7, 5);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(531, 45);
            this.label15.TabIndex = 0;
            this.label15.Text = "REPROP_CS DEMO demos the integration of RefProp into C#.Net Applications. \r\n\r\nThi" +
    "s program uses IRefProp64.dll, which is a C# wrapper class for the  RefProp Fort" +
    "ran methods.\r\n";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(839, 332);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "REFPROP_CS DEMO";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView_1st)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DataGridView_2ndTab)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.groupBox13.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.groupBox16.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_vapor_props)).EndInit();
            this.groupBox15.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_liquid_props)).EndInit();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataGridView DataGridView_1st;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TextBox_1stTab_DewPoint;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TextBox_1stTab_BubblePoint;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox TextBox_1stTab_MolecularWeight;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox TextBox_1stRab_RefPropDLLVersion;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox TextBox_1stRab_CriticalPoint_Density;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox TextBox_1stRab_CriticalPoint_Press;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox TextBox_1stRab_CriticalPoint_Temp;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox TextBox_total_1stTab;
        private System.Windows.Forms.Label Label_Total_1stTab;
        private System.Windows.Forms.TextBox TextBox_R143A_FLD;
        private System.Windows.Forms.TextBox TextBox_R134A_FLD;
        private System.Windows.Forms.TextBox TextBox_R125_FLD;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_t_1stTab;
        private System.Windows.Forms.TextBox textBox_p_1stTab;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DataGridView DataGridView_2ndTab;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox TextBox_TempPro_DewPoint;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox TextBox_TempPro_BubblePoint;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox TextBox_TempPro_MolecularWeight;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.TextBox TextBox_TempPro_RefPropDLLVersion;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox TextBox_TempPro_CriticalPoint_Density;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox TextBox_TempPro_CriticalPoint_Press;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox TextBox_TempPro_CriticalPoint_Temp;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox TextBox_InputSheet_Total;
        private System.Windows.Forms.Label Label_Total;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button Button_TempPro_Clear;
        private System.Windows.Forms.Button Button_TempPro_Calculate;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox TextBox_InputSheet_Nitrogen;
        private System.Windows.Forms.TextBox TextBox_InputSheet_Isopentane;
        private System.Windows.Forms.TextBox TextBox_InputSheet_Pentane;
        private System.Windows.Forms.TextBox TextBox_InputSheet_Isobutane;
        private System.Windows.Forms.TextBox TextBox_InputSheet_Butane;
        private System.Windows.Forms.TextBox TextBox_InputSheet_Propane;
        private System.Windows.Forms.TextBox TextBox_InputSheet_Ethane;
        private System.Windows.Forms.TextBox TextBox_InputSheet_Methane;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox t_textBox_2ndTab;
        private System.Windows.Forms.TextBox p_textBox_2ndTab;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.DataGridView dataGridView_vapor_props;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.DataGridView dataGridView_liquid_props;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.ComboBox comboBox_hflnme;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox textBox_t_3rdTab;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn xvap_0;
        private System.Windows.Forms.DataGridViewTextBoxColumn xvap_1;
        private System.Windows.Forms.DataGridViewTextBoxColumn xvap_2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn kph;
        private System.Windows.Forms.DataGridViewTextBoxColumn p;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn xliq_0;
        private System.Windows.Forms.DataGridViewTextBoxColumn xliq_1;
        private System.Windows.Forms.DataGridViewTextBoxColumn xliq_2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
    }
}

