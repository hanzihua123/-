## Mathcad 15 Handbooks (e-Books)

These files should be copied to the Handbook directory of the Mathcad 15 installation folder.  This folder is typically located at:

    `C:\Program Files (x86)\Mathcad\Mathcad 15\Handbook`

**NOTE: This will happen automatically as part of the Visual Studio Post-Build process if using the provided solution file.**

The electronic handbook documentation for **NIST RefProp** will then be available in the Mathcad 15 interface under Help | E-books > NIST RefProp.
