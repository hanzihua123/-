---
title: Online Tools
template: index.pug
description: Online tools provides md2, md5, sha1, sha2, sha512, bas64, html encode / decode functions
keywords: online,md5,sha1,sha2,sha,sha512,base64,md2,htmlencode,htmldecode
---
Please contact [emn178@gmail.com](mailto:emn178@gmail.com) or [create issues](https://github.com/emn178/online-tools/issues) if any problem.
