---
title: Base32 Encode File
template: page.pug
js: https://cdn.jsdelivr.net/gh/emn178/hi-base32@v0.5.1/build/base32.min.js
method: base32.encode
action: Encode
auto_update: true
file_input: true
description: Base32 online encode file function
keywords: Base32,online,encode,file
---
