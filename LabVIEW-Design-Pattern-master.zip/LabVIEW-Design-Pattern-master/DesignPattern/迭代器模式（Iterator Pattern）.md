迭代器模式
---------------

###参考
- [迭代器模式 wikipedia](https://zh.wikipedia.org/wiki/%E8%BF%AD%E4%BB%A3%E5%99%A8%E6%A8%A1%E5%BC%8F)