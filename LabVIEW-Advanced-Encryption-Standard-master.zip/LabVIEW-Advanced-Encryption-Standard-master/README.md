![alt tag](https://github.com/IgorTitov/LabVIEW-Advanced-Encryption-Standard/blob/master/Examples/AES_LabVIEW_image.png)

# Advanced Encryption Standard (AES) - Native LabVIEW Library

Official site: https://vfpsoft.com  

## Introduction

This is a native LabVIEW implementation of AES algorithm. It can run on Windows, Mac and Linux operating systems.


Issues are being tracked here on GitHub.

## License

`AES LabVIEW Library`'s code in this repo uses the MIT license, see our `LICENSE` file.

