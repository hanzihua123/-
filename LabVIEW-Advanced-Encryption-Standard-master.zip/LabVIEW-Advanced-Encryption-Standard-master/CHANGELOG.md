# Change Log
Advanced Encryption Standard (AES256) LabVIEW library changes.

## [Unreleased]
### Added
- Unit tests

### Fixed
- Wrong test vectors (for input strings 38, 39, 86, 87, 134 or 135 bytes long).


## [1.0.0] - 2017-03-23
### Added
- Initial public release