# LabVIEW-Transcript-DLL-Library
Example usage LabVIEW Universal Transcriptor to create DLL library using MinGW compiler.
